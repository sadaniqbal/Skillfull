import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { PersonService } from '../../../assets/data/person.service';
import { PhotoService } from '../../services/photo.service'

@Component({
  selector: 'app-newperson',
  templateUrl: './newperson.page.html',
  styleUrls: ['./newperson.page.scss'],
})
export class NewpersonPage implements OnInit {
  form: FormGroup
  constructor(private personService: PersonService,
    private router: Router,
    private photoService: PhotoService) { }

  ngOnInit() {
    this.form = new FormGroup({
      name: new FormControl(null,{
        updateOn: "blur",
        validators: [Validators.required]
      }),
      category: new FormControl(null,{
        updateOn: "blur",
        validators: [Validators.required]
      }),
      description: new FormControl(null,{
        updateOn: "blur",
        validators: [Validators.required, Validators.maxLength(180)]
      }),
      wage: new FormControl(null,{
        updateOn: "blur",
        validators: [Validators.required, Validators.min(1)]
      }),
      availableFrom: new FormControl(null,{
        updateOn: "blur",
        validators: [Validators.required]
      }),
      availableTo: new FormControl(null,{updateOn: "blur",
      validators: [Validators.required]}),
    });
  }


  clickPicture(){this.photoService.addNewToGallery()}
  
  onCreateperson(){
    console.log(this.form);
    this.personService.addPerson(
      this.form.value.name,
      this.form.value.category,
      this.form.value.description,
      this.form.value.wage,
      new Date(this.form.value.availableFrom),
      new Date(this.form.value.availableTo),
    );
    this.form.reset();
    this.router.navigate(['/tabs/tab2'])
  }

  
}
